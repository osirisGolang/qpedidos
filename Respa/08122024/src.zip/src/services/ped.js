export default [
  {
    nombre: "Luis",
    apellido: ["Gomez", "Suarez"],
  },
  {
    nombre: "Carlos",
    apellido: "Gardel",
  },
];
