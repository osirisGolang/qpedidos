<template>
  <div class="q-pa-md">
    <div class="q-col-gutter-md row items-start">
      <div class="col-6">
        <q-img src="~assets/sensor3.jpg">
          <div class="absolute-bottom text-subtitle1 text-center">
            SENSOR TPS 3 PINES FIESTA ECOSPORT
          </div>
        </q-img>
      </div>

      <div class="col-6">
        <q-img src="~assets/sensor4.jpg">
          <div class="absolute-top text-center">
            SENSOR ARBOL DE LEVA FIESTA MAX 3 PINES 67-9S6G12K073AA
          </div>
        </q-img>
      </div>

      <div class="col-6">
        <q-img src="~assets/sensor5.png">
          <div class="absolute-bottom-right text-subtitle2">
            Sensor Detonación Gran Vitara Chevrolet
          </div>
        </q-img>
      </div>

      <div class="col-6">
        <q-img src="~assets/sensor6.png">
          <div class="absolute-full text-subtitle2 flex flex-center">
            Sensor Oxigeno Fiat Palio Siena 1.8
          </div>
        </q-img>
      </div>
    </div>
  </div>
</template>