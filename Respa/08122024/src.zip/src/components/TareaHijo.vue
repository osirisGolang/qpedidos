<template>
  <div>
    <slot></slot>
  </div>
</template>

<script setup>
</script>

<style scoped>
</style>
