<template>
  <div class="q-ma-lg">
    <p>taREAS vUE</p>
  </div>
</template>

<script setup>
</script>

<style scoped>
</style>